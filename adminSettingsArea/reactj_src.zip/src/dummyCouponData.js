export default [
  {
    couponId : 1,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 2,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 3,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 4,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 5,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 6,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 7,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 8,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 9,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 10,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 11,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
  {
    couponId : 12,
    pageTarget : 'http://google.com',
    displayThreshold : 5,
    numberOfOffers : 3,
    headlineTextColor : 'black',
    headlineBackgroundColor : 'white',
    descriptionTextColor : 'black',
    descriptionBackgroundColor : 'white'
  },
]